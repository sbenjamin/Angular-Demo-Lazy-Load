angular.module("app").controller('AppCtrl', function() {
    this.text = "Hello from the Ctrl";
});